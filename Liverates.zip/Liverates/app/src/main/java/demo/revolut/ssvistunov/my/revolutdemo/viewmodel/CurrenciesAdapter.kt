package demo.revolut.ssvistunov.my.revolutdemo.viewmodel

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView

import com.jakewharton.rxbinding2.widget.RxTextView

import java.util.HashMap
import java.util.Locale

import butterknife.BindView
import butterknife.ButterKnife
import demo.revolut.ssvistunov.my.revolutdemo.R
import demo.revolut.ssvistunov.my.revolutdemo.viewmodel.model.Currency
import io.reactivex.disposables.Disposable

class CurrenciesAdapter private constructor(private val viewModel: CurrenciesViewModel) : RecyclerView.Adapter<CurrenciesAdapter.CurrencyItemiewHolder>() {
    private val editTextCache = HashMap<String, EditText>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CurrencyItemiewHolder {
        val rowView = LayoutInflater.from(parent.context).inflate(R.layout.currency_item, parent, false)
        return CurrencyItemiewHolder(rowView)
    }

    override fun onBindViewHolder(holder: CurrencyItemiewHolder, position: Int) {
        val item = viewModel.modelList[position]
        bindToViewHolder(holder, item)
    }

    private fun bindToViewHolder(holder: CurrencyItemiewHolder, item: Currency) {
        fillWithCurrentModel(holder, item)
        setActionsForClickAndFocus(holder, item)
        editTextCache[item.name] = holder.editRate
    }

    private fun setActionsForClickAndFocus(holder: CurrencyItemiewHolder, item: Currency) {
        //Set action for click on whole view
        holder.itemView.setOnClickListener { swapToZeroPositionAndAnimate(item, holder) }
        //Set action for in focus for EditText
        holder.editRate!!.onFocusChangeListener = View.OnFocusChangeListener { view, isInFocus -> handleFocusForItem(isInFocus, item, holder) }
    }

    private fun fillWithCurrentModel(holder: CurrencyItemiewHolder, item: Currency) {
        //Fill view with data
        holder.textLabel!!.text = item.name
        setValueToEditText(holder.editRate!!, item.koef!!)
    }

    private fun handleFocusForItem(isInFocus: Boolean, item: Currency, holder: CurrencyItemiewHolder) {
        if (isInFocus) {
            swapToZeroPositionAndAnimate(item, holder)
            holder.setReactiveEditText(subscribeToTextEvents(item, holder))
            positionCursorBeforePoint(holder)
        } else {
            disposeAndRemoveKeyboard(holder)
        }
    }

    private fun disposeAndRemoveKeyboard(holder: CurrencyItemiewHolder) {
        //Dispose
        holder.disposeReactiveEditTextIfPossible()
        //Remove soft keyboardd
        val imm = holder.itemView.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm?.hideSoftInputFromWindow(holder.editRate!!.windowToken, 0)
    }

    private fun positionCursorBeforePoint(holder: CurrencyItemiewHolder) {
        val posOfBeforePoint = holder.editRate!!.text.toString().lastIndexOf(".") - 1
        holder.editRate!!.setSelection(posOfBeforePoint)
    }

    private fun subscribeToTextEvents(item: Currency, holder: CurrencyItemiewHolder): Disposable {
        return RxTextView.textChanges(holder.editRate!!)
                .skip(1)
                .map { text -> helperMapEmptyStringToZero(text.toString()) }
                .map<Float>(Function<String, Float> { java.lang.Float.parseFloat(it) })
                .doOnNext { value ->
                    viewModel.modifyCurrentAmountWithItem(value!!, item.koef!!)
                    updateAllCurrencyValues()
                }
                .subscribe()
    }

    private fun helperMapEmptyStringToZero(str: String?): String {
        return if (str == null || str.isEmpty() || str == ".")
            "0"
        else
            str
    }

    private fun setValueToEditText(editText: EditText, koef: Float) {
        val result = koef * viewModel.currentAmount!!
        editText.setText(String.format(Locale.US, "%.2f", result))
    }

    override fun getItemCount(): Int {
        return viewModel.modelList.size
    }

    private fun swapToZeroPositionAndAnimate(item: Currency, holder: CurrencyItemiewHolder) {
        //Old position
        val pos = viewModel.modelList.indexOf(item)
        //
        //        //swap if possible
        if (viewModel.modelList.remove(item)) {
            viewModel.modelList.add(0, item)

            //set focus to top element
            holder.editRate!!.requestFocus()

            // Show soft keyboard for the user to enter the value.
            val imm = holder.itemView.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm?.showSoftInput(holder.editRate, InputMethodManager.SHOW_IMPLICIT)

            //let recyclerView refresh and animate it
            notifyItemMoved(pos, 0)
        }
    }

    fun updateAllCurrencyValues() {
        for (currencyName in editTextCache.keys) {
            val koef = getKoefByName(currencyName)
            updateCurrencyValue(currencyName, koef)
        }
    }

    private fun updateCurrencyValue(currencyName: String, koef: Float?) {
        val editText = editTextCache[currencyName]

        var isTopItem = false
        if (viewModel.modelList.size > 0) {
            val topItem = viewModel.modelList[0]
            if (topItem.name == currencyName)
                isTopItem = true
        }

        if (!isTopItem)
            setValueToEditText(editText, koef!!)
    }

    private fun getKoefByName(name: String): Float? {
        for (item in viewModel.modelList) {
            if (item.name == name)
                return item.koef
        }
        return java.lang.Float.NaN
    }


    internal inner class CurrencyItemiewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        @BindView(R.id.currency_label)
        var textLabel: TextView? = null

        @BindView(R.id.currency_rateValue)
        var editRate: EditText? = null

        private var reactiveEditText: Disposable? = null

        init {
            ButterKnife.bind(this, itemView)
        }

        fun disposeReactiveEditTextIfPossible() {
            if (reactiveEditText != null)
                reactiveEditText!!.dispose()
        }

        fun setReactiveEditText(reactiveEditText: Disposable) {
            this.reactiveEditText = reactiveEditText
        }
    }

    companion object {

        private val VIEW_TYPE_EMPTY_LIST_PLACEHOLDER = 0
        private val VIEW_TYPE_OBJECT_VIEW = 1

        fun create(viewModel: CurrenciesViewModel): CurrenciesAdapter {
            return CurrenciesAdapter(viewModel)
        }
    }
}
