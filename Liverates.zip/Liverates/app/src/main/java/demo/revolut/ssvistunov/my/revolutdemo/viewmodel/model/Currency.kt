package demo.revolut.ssvistunov.my.revolutdemo.viewmodel.model

class Currency private constructor(val name: String, var koef: Float?) {
    companion object {

        fun create(name: String, koef: Float?): Currency {
            return Currency(name, koef)
        }
    }
}
