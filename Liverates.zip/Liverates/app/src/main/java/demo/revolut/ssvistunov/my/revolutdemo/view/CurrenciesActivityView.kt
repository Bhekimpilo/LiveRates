package demo.revolut.ssvistunov.my.revolutdemo.view

import android.support.v7.widget.RecyclerView

/**
 * Created by SSvistunov on 17.11.2017.
 */

interface CurrenciesActivityView {

    fun initList(adapter: RecyclerView.Adapter<*>)
    fun showError(errorString: String)
}
