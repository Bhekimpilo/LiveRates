package demo.revolut.ssvistunov.my.revolutdemo.model.repository

interface RepositoryListener {
    fun currenciesFromNetwork(data: Map<String, Float>)
    fun errorFromRepository(errorString: String)
}
