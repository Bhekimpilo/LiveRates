package demo.revolut.ssvistunov.my.revolutdemo

/**
 * Created by ssvistunov on 16/11/2017.
 */

object Config {
    val BASE_URL = "https://revolut.duckdns.org"
    val BASE_CURRENCY = "EUR"
    val BASE_AMOUNT = 100.0f
}
