package demo.revolut.ssvistunov.my.revolutdemo

import android.app.Application

import demo.revolut.ssvistunov.my.revolutdemo.di.AppComponent
import demo.revolut.ssvistunov.my.revolutdemo.di.DaggerAppComponent
import demo.revolut.ssvistunov.my.revolutdemo.di.RepositoryModule
import demo.revolut.ssvistunov.my.revolutdemo.model.network.NetworkManager


class App : Application() {

    override fun onCreate() {
        super.onCreate()

        component = buildComponent()

    }

    private fun buildComponent(): AppComponent {
        return DaggerAppComponent.builder()
                .repositoryModule(RepositoryModule(applicationContext, NetworkManager()))
                .build()
    }

    companion object {

        var component: AppComponent? = null
            private set
    }
}
