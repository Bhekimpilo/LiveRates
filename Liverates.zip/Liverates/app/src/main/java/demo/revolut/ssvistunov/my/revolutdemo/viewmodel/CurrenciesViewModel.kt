package demo.revolut.ssvistunov.my.revolutdemo.viewmodel

import android.support.v7.widget.RecyclerView

import java.util.ArrayList
import java.util.Collections

import demo.revolut.ssvistunov.my.revolutdemo.Config
import demo.revolut.ssvistunov.my.revolutdemo.model.repository.CurrencyRepository
import demo.revolut.ssvistunov.my.revolutdemo.model.repository.RepositoryListener
import demo.revolut.ssvistunov.my.revolutdemo.view.CurrenciesActivityView
import demo.revolut.ssvistunov.my.revolutdemo.viewmodel.model.Currency
import java.util.Collections.emptyList

class CurrenciesViewModel(private val repository: CurrencyRepository) : RepositoryListener {
    private var view: CurrenciesActivityView? = null

    private var currenciesAdapter: CurrenciesAdapter? = null
    var modelList = emptyList<Currency>()
        private set
    var currentAmount: Float? = Config.BASE_AMOUNT
        private set

    fun attachView(view: CurrenciesActivityView) {
        this.view = view
        repository.setListener(this)
        repository.getDataFromNetworkAndListen()
        createListModelIfNeeded(repository.dataFromCache)
    }

    private fun createListModelIfNeeded(ratesFromCache: Map<String, Float>) {
        if (modelList.size == 0) {
            modelList = mapRepoDataToModel(ratesFromCache)
            view!!.initList(buildAdapter())
        }
    }

    fun detachView() {
        currenciesAdapter = null
        repository.shutdownGettingDataFromNetwork()
        repository.removeListener()
        this.view = null
    }

    private fun buildAdapter(): RecyclerView.Adapter<*> {
        if (currenciesAdapter == null)
            currenciesAdapter = CurrenciesAdapter.create(this)
        return currenciesAdapter as CurrenciesAdapter
    }

    private fun mapRepoDataToModel(repoData: Map<String, Float>?): List<Currency> {
        val returnValue = ArrayList<Currency>()
        if (repoData != null) {
            for (currencyName in repoData.keys) {
                val value = repoData[currencyName]
                if (currencyName == Config.BASE_CURRENCY)
                    returnValue.add(0, Currency.create(currencyName, value))
                else
                    returnValue.add(Currency.create(currencyName, value))
            }
        }
        return returnValue
    }

    override fun currenciesFromNetwork(data: Map<String, Float>) {
        if (modelList.size == 0)
            createListModelIfNeeded(data)
        else {
            updateListModelWithNewData(data)
            if (currenciesAdapter != null)
                currenciesAdapter!!.updateAllCurrencyValues()
            else
                view!!.initList(buildAdapter())
        }
    }

    private fun updateListModelWithNewData(data: Map<String, Float>) {
        for (currencyName in data.keys) {
            val value = data[currencyName]

            for (item in modelList) {
                if (item.name == currencyName) {
                    item.koef = value
                    break
                }
            }
        }
    }

    override fun errorFromRepository(errorString: String) {
        view!!.showError(errorString)
    }

    fun modifyCurrentAmountWithItem(newValue: Float, koef: Float) {
        if (koef > 0.0f)
            this.currentAmount = newValue / koef
    }

}
