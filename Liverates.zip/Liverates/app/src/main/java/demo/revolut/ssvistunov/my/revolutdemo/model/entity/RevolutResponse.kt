package demo.revolut.ssvistunov.my.revolutdemo.model.entity

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

import java.util.LinkedHashMap
import java.util.TreeMap

class RevolutResponse {

    @SerializedName("base")
    @Expose
    var base: String? = null
    @SerializedName("date")
    @Expose
    var date: String? = null
    @SerializedName("rates")
    @Expose
    var rates: TreeMap<String, Float>? = null
}
