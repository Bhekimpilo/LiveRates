package demo.revolut.ssvistunov.my.revolutdemo.model.network

import android.util.Log


import java.util.concurrent.TimeUnit

import demo.revolut.ssvistunov.my.revolutdemo.model.entity.RevolutResponse
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import demo.revolut.ssvistunov.my.revolutdemo.Config.BASE_CURRENCY
import demo.revolut.ssvistunov.my.revolutdemo.Config.BASE_URL
import io.reactivex.ObservableSource

class NetworkManager {

    private val revolutRetrofitService: RevolutRetrofitService
    private var networkObservable: Disposable? = null

    init {
        //Init retrofit
        val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build()
        revolutRetrofitService = retrofit.create(RevolutRetrofitService::class.java)
    }

    fun requestDataAndListen(callback: NetworkListener) {

        networkObservable = Observable.interval(1, TimeUnit.SECONDS)
                .flatMap<RevolutResponse> { n ->
                    revolutRetrofitService?.getCurrencies(BASE_CURRENCY)!!
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .doOnNext { currencies: RevolutResponse ->
                                Log.d("server", currencies.base + "   " + currencies.date)
                                callback.onSuccess(currencies)
                            }
                            .doOnError { throwable: Throwable ->
                                Log.e("server", "Error: " + throwable.message)
                                callback.onFailure(throwable)
                            }
                }.subscribe()
    }

    fun shutdownRequestsToServer() {
        if (null != networkObservable) {
            networkObservable!!.dispose()
            networkObservable = null
        }
    }

    interface NetworkListener {
        fun onSuccess(currencies: RevolutResponse)
        fun onFailure(t: Throwable)
    }
}
