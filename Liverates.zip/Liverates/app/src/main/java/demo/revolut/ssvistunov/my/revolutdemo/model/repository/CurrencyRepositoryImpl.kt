package demo.revolut.ssvistunov.my.revolutdemo.model.repository

import android.content.Context
import android.os.Build
import android.support.annotation.RequiresApi
import android.util.Log

import com.google.gson.Gson

import demo.revolut.ssvistunov.my.revolutdemo.model.entity.RevolutResponse
import demo.revolut.ssvistunov.my.revolutdemo.model.network.NetworkManager
import io.reactivex.Flowable
import io.reactivex.schedulers.Schedulers
import java.lang.String.valueOf

class CurrencyRepositoryImpl(context: Context, private val networkManager: NetworkManager) : CurrencyRepository {

    private var currencies: RevolutResponse? = null
    private var prefManager: SharedPrefManager

    private var listener: RepositoryListener? = null

    override val dataFromCache: Map<String, Float>
        get() {
            val cachedData = prefManager.load()
            currencies = Gson().fromJson<RevolutResponse>(cachedData, RevolutResponse::class.java)
            if (currencies != null && currencies!!.rates != null) {
                addBaseCurrencyToBeginOfList()
                return currencies?.rates!!
            }
            val nuT: Map<String, Float>? = null

            return nuT!!
        }

    init {
        this.prefManager = SharedPrefManager(context)
    }

    fun addBaseCurrencyToBeginOfList() {
        currencies?.base = valueOf(1.0f)
    }

    override fun getDataFromNetworkAndListen() {

        networkManager.requestDataAndListen(object : NetworkManager.NetworkListener {
            @RequiresApi(Build.VERSION_CODES.GINGERBREAD)
            override fun onSuccess(newCurrencies: RevolutResponse) {
                currencies = newCurrencies
                if (listener != null)
                    listener!!.currenciesFromNetwork(proceedToListener(currencies!!)!!)
                startSavingData(newCurrencies)
            }

            override fun onFailure(t: Throwable) {
                Log.e("failure", t.localizedMessage)
                val errorString = if (t != null) t.localizedMessage else "Unknown error"
                if (listener != null)
                    listener!!.errorFromRepository(errorString)
            }
        })
    }

    @RequiresApi(Build.VERSION_CODES.GINGERBREAD)
    private fun startSavingData(newCurrencies: RevolutResponse) {
        val stringData = Gson().toJson(newCurrencies)
        Flowable.just(stringData)
                .subscribeOn(Schedulers.io())
                .doOnNext { str -> prefManager.save(str) }
                .subscribe()
    }

    override fun shutdownGettingDataFromNetwork() {
        networkManager.shutdownRequestsToServer()
    }

    override fun setListener(listener: RepositoryListener) {
        this.listener = listener
    }

    override fun removeListener() {
        this.listener = null
    }

    private fun proceedToListener(currencies: RevolutResponse): Map<String, Float>? {
        this.currencies = currencies
        addBaseCurrencyToBeginOfList()
        return currencies.rates
    }
}
