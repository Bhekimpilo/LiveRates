package demo.revolut.ssvistunov.my.revolutdemo.view

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.TreeMap

import javax.inject.Inject

import butterknife.BindView
import butterknife.ButterKnife
import demo.revolut.ssvistunov.my.revolutdemo.App
import demo.revolut.ssvistunov.my.revolutdemo.R
import demo.revolut.ssvistunov.my.revolutdemo.viewmodel.CurrenciesViewModel

class CurrenciesActivity : AppCompatActivity(), CurrenciesActivityView {

    @Inject
    var viewModel: CurrenciesViewModel? = null

    @BindView(R.id.rates_list)
    internal var ratesList: RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_currencies)
        ButterKnife.bind(this)
        App.component.inject(this)
    }

    override fun onStart() {
        super.onStart()
        viewModel!!.attachView(this)
    }

    override fun initList(adapter: RecyclerView.Adapter<*>) {
        ratesList!!.layoutManager = LinearLayoutManager(this)
        ratesList!!.setHasFixedSize(true)
        ratesList!!.setItemViewCacheSize(adapter.itemCount)
        ratesList!!.adapter = adapter
    }

    override fun showError(errorString: String) {
        Toast.makeText(this, errorString, Toast.LENGTH_SHORT).show()
    }

    override fun onStop() {
        ratesList!!.adapter = null
        viewModel!!.detachView()
        super.onStop()
    }
}
