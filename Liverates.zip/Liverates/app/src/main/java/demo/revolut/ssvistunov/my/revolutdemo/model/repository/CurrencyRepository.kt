package demo.revolut.ssvistunov.my.revolutdemo.model.repository

import java.util.TreeMap
import java.util.concurrent.Callable

interface CurrencyRepository {

    val dataFromCache: Map<String, Float>
    fun getDataFromNetworkAndListen()
    fun shutdownGettingDataFromNetwork()

    fun setListener(listener: RepositoryListener)
    fun removeListener()
}
